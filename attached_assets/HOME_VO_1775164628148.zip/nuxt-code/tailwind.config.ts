import type { Config } from 'tailwindcss'

export default {
  content: [
    './components/**/*.{js,vue,ts}',
    './layouts/**/*.vue',
    './pages/**/*.vue',
    './plugins/**/*.{js,ts}',
    './app.vue',
  ],
  theme: {
    extend: {
      colors: {
        // Brand Colors
        'teal': {
          DEFAULT: '#2F7785',
          dark: '#225F6B',
        },
        'lime': {
          DEFAULT: '#98C73A',
        },
        'off-white': '#F4F4F5',
        'gold': '#F5C518',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
} satisfies Config
