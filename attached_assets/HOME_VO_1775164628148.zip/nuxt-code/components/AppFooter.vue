<template>
  <footer class="bg-[#225F6B] text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
        <!-- Brand Column -->
        <div class="col-span-2 lg:col-span-1">
          <img 
            src="/images/quanta-shop-white.png" 
            alt="Quanta Shop" 
            class="h-10 w-auto mb-4"
          />
          <p class="text-white/80 text-sm leading-relaxed">
            Seu Ecossistema de Fidelidade e Renda Recorrente.
          </p>
          
          <!-- Social Links -->
          <div class="flex space-x-4 mt-6">
            <a 
              href="https://instagram.com/quantashop" 
              target="_blank"
              rel="noopener noreferrer"
              class="text-white/70 hover:text-white transition-colors"
              aria-label="Instagram"
            >
              <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
            </a>
            <a 
              href="https://linkedin.com/company/quantashop" 
              target="_blank"
              rel="noopener noreferrer"
              class="text-white/70 hover:text-white transition-colors"
              aria-label="LinkedIn"
            >
              <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
              </svg>
            </a>
            <a 
              href="https://youtube.com/@quantashop" 
              target="_blank"
              rel="noopener noreferrer"
              class="text-white/70 hover:text-white transition-colors"
              aria-label="YouTube"
            >
              <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
              </svg>
            </a>
          </div>
        </div>

        <!-- Institucional -->
        <div>
          <h3 class="font-semibold text-white mb-4">Institucional</h3>
          <ul class="space-y-3">
            <li>
              <NuxtLink to="/sobre" class="text-white/70 hover:text-white transition-colors text-sm">
                Sobre Nos
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/carreiras" class="text-white/70 hover:text-white transition-colors text-sm">
                Carreiras
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/blog" class="text-white/70 hover:text-white transition-colors text-sm">
                Blog
              </NuxtLink>
            </li>
          </ul>
        </div>

        <!-- Para Voce -->
        <div>
          <h3 class="font-semibold text-white mb-4">Para Voce</h3>
          <ul class="space-y-3">
            <li>
              <NuxtLink to="/como-funciona" class="text-white/70 hover:text-white transition-colors text-sm">
                Como Funciona
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/cashback" class="text-white/70 hover:text-white transition-colors text-sm">
                Cashback
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/ofertas" class="text-white/70 hover:text-white transition-colors text-sm">
                Ofertas
              </NuxtLink>
            </li>
          </ul>
        </div>

        <!-- Para sua Empresa -->
        <div>
          <h3 class="font-semibold text-white mb-4">Para sua Empresa</h3>
          <ul class="space-y-3">
            <li>
              <NuxtLink to="/para-empresa" class="text-white/70 hover:text-white transition-colors text-sm">
                Credenciamento
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/seja-agente" class="text-white/70 hover:text-white transition-colors text-sm">
                Seja um Agente
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/parceiros" class="text-white/70 hover:text-white transition-colors text-sm">
                Parceiros
              </NuxtLink>
            </li>
          </ul>
        </div>

        <!-- Ajuda -->
        <div>
          <h3 class="font-semibold text-white mb-4">Ajuda</h3>
          <ul class="space-y-3">
            <li>
              <NuxtLink to="/faq" class="text-white/70 hover:text-white transition-colors text-sm">
                FAQ
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/contato" class="text-white/70 hover:text-white transition-colors text-sm">
                Contato
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/privacidade" class="text-white/70 hover:text-white transition-colors text-sm">
                Privacidade
              </NuxtLink>
            </li>
            <li>
              <NuxtLink to="/termos" class="text-white/70 hover:text-white transition-colors text-sm">
                Termos de Uso
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>

      <!-- Bottom Bar -->
      <div class="border-t border-white/20 mt-12 pt-8">
        <div class="flex flex-col md:flex-row justify-between items-center gap-4">
          <p class="text-white/60 text-sm text-center md:text-left">
            &copy; {{ currentYear }} Quanta Shop. Todos os direitos reservados.
          </p>
          <p class="text-white/60 text-sm text-center md:text-right">
            CNPJ: 00.000.000/0001-00 | Rio de Janeiro, RJ
          </p>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup lang="ts">
const currentYear = computed(() => new Date().getFullYear())
</script>
