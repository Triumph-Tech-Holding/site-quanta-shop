<template>
  <header class="bg-white shadow-sm sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16 lg:h-20">
        <!-- Logo -->
        <div class="flex-shrink-0">
          <NuxtLink to="/">
            <img 
              src="/images/quanta-shop.png" 
              alt="Quanta Shop" 
              class="h-10 lg:h-12 w-auto"
            />
          </NuxtLink>
        </div>

        <!-- Desktop Navigation -->
        <nav class="hidden lg:flex items-center space-x-8">
          <NuxtLink 
            v-for="item in menuItems" 
            :key="item.label"
            :to="item.href"
            class="text-[#2F7785] font-medium hover:text-[#225F6B] transition-colors"
          >
            {{ item.label }}
          </NuxtLink>
        </nav>

        <!-- CTAs -->
        <div class="hidden lg:flex items-center space-x-4">
          <NuxtLink 
            to="/login" 
            class="text-[#2F7785] font-medium hover:text-[#225F6B] transition-colors"
          >
            Login
          </NuxtLink>
          <NuxtLink 
            to="/cadastro" 
            class="bg-[#98C73A] text-[#225F6B] font-semibold px-6 py-2.5 rounded-full hover:bg-[#8ab832] transition-colors"
          >
            Cadastrar Gratis
          </NuxtLink>
        </div>

        <!-- Mobile Menu Button -->
        <button 
          @click="mobileMenuOpen = !mobileMenuOpen"
          class="lg:hidden p-2 text-[#2F7785]"
          aria-label="Menu"
        >
          <svg v-if="!mobileMenuOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
          <svg v-else class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <!-- Mobile Menu -->
      <Transition
        enter-active-class="transition duration-200 ease-out"
        enter-from-class="opacity-0 -translate-y-2"
        enter-to-class="opacity-100 translate-y-0"
        leave-active-class="transition duration-150 ease-in"
        leave-from-class="opacity-100 translate-y-0"
        leave-to-class="opacity-0 -translate-y-2"
      >
        <div v-if="mobileMenuOpen" class="lg:hidden pb-4">
          <nav class="flex flex-col space-y-3">
            <NuxtLink 
              v-for="item in menuItems" 
              :key="item.label"
              :to="item.href"
              class="text-[#2F7785] font-medium py-2 hover:text-[#225F6B] transition-colors"
              @click="mobileMenuOpen = false"
            >
              {{ item.label }}
            </NuxtLink>
            <div class="flex flex-col space-y-3 pt-4 border-t border-gray-200">
              <NuxtLink 
                to="/login" 
                class="text-[#2F7785] font-medium py-2"
                @click="mobileMenuOpen = false"
              >
                Login
              </NuxtLink>
              <NuxtLink 
                to="/cadastro" 
                class="bg-[#98C73A] text-[#225F6B] font-semibold px-6 py-2.5 rounded-full text-center"
                @click="mobileMenuOpen = false"
              >
                Cadastrar Gratis
              </NuxtLink>
            </div>
          </nav>
        </div>
      </Transition>
    </div>
  </header>
</template>

<script setup lang="ts">
const mobileMenuOpen = ref(false)

const menuItems = [
  { label: 'Para voce', href: '/para-voce' },
  { label: 'Para sua Empresa', href: '/para-empresa' },
  { label: 'Seja um Agente', href: '/seja-agente' },
  { label: 'Quanta Amizade', href: '/quanta-amizade' },
  { label: 'Fale Conosco', href: '/contato' },
]
</script>
