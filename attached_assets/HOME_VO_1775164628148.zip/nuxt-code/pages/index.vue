<template>
  <div class="min-h-screen bg-[#F4F4F5]">
    <AppHeader />
    
    <main>
      <HeroCarousel />
      
      <OmniSearch />
      
      <BrandsCarousel />
      
      <DailyOffers />
      
      <LocalCashback />
      
      <CeoBanner />
    </main>

    <AppFooter />
  </div>
</template>

<script setup lang="ts">
useHead({
  title: 'Quanta Shop - Cashback de Verdade em Cada Compra',
  meta: [
    { 
      name: 'description', 
      content: 'Transforme seus gastos diarios em saldo CCR que cresce todo dia. Dinheiro na conta, nao pontos. O melhor cashback do Brasil.' 
    },
    { name: 'theme-color', content: '#225F6B' },
  ],
})

useSeoMeta({
  ogTitle: 'Quanta Shop - Cashback de Verdade em Cada Compra',
  ogDescription: 'Transforme seus gastos diarios em saldo CCR que cresce todo dia. Dinheiro na conta, nao pontos.',
  ogImage: '/images/og-image.jpg',
  twitterCard: 'summary_large_image',
})
</script>
